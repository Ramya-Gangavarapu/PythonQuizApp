$(document).ready(function() {
    const questions = [{
            question: "Question 1: What is a variable in Python?",
            options: ["A fixed value", "A reserved keyword", "A container for storing data", "A mathematical operation"],
            correctAnswer: "A container for storing data",
        },
        {
            question: "Question 2: Which of the following is a valid variable name in Python?",
            options: ["1stNumber", "total_count", "break", "my-variable"],
            correctAnswer: "total_count",
        },
        {
            question: "Question 3: What is the correct way to create a variable in Python?",
            options: ["Variable-Name := 10", "123variable = 42", "name = 'variable'", "variable_name = value"],
            correctAnswer: "variable_name = value",
        },
        {
            question: "Question 4: What will be the value of x after executing x = 5; x = x + 2?",
            options: ["5", "2", "7", "10"],
            correctAnswer: "7",
        },
        {
            question: "Question 5:Which of the following is a valid way to comment a line in Python? ",
            options: ["<!-- This is a comment -->", "/* This is a comment */ ", "# This is a comment", "// This is a comment"],
            correctAnswer: "# This is a comment",
        },
        {
            question: "Question 6: What does the id() function in Python return?",
            options: ["The data type of a variable", "The memory address of an object", "The value of a variable", "The length of a string"],
            correctAnswer: "The memory address of an object",
        },
        {
            question: "Question 7: Which of the following is a valid variable assignment in Python?",
            options: ["x + 5", "x == 5", "x = 5", "5 = x"],
            correctAnswer: "x = 5",
        },
        {
            question: "Question 8: Which function is used to check the data type of a variable in Python?",
            options: ["variableType()", "typeof()", "datatype()", "type()"],
            correctAnswer: "type()",
        },
        {
            question: "Question 9: What is the output of print('Hello, ' + name) if name is not defined?",
            options: ["Hello,", "Hello, None", "Hello, undefined", "Error: name is not defined"],
            correctAnswer: "Error: name is not defined",
        },
        {
            question: "Question 10: In Python, can a variable's data type be changed after it is assigned a value?",
            options: ["Yes", "No"],
            correctAnswer: "Yes",
        },
        {
            question: "Question 11:What is the output of print(len('Hello'))? ",
            options: ["5", "6", "4", "Error"],
            correctAnswer: "5",
        },
        {
            question: "Question 12: What is the purpose of the globals() function in Python?",
            options: ["To check if a variable is global", "To delete global variables", "To access global variables", "To create global variables"],
            correctAnswer: "To access global variables",
        },
        {
            question: "Question 13:What is the data type of the variable x in Python if x = 5? ",
            options: ["Boolean", "Float", "String", "Integer"],
            correctAnswer: "Integer",
        },
        {
            question: "Question 14:Which data type is used to represent text in Python? ",
            options: ["Integer ", "Float ", "String ", "List "],
            correctAnswer: "String ",
        },
        {
            question: "Question 15: What is the value of 5 + 2.0 in Python? ",
            options: ["7 ", "7.0 ", "'52.0' ", "Error "],
            correctAnswer: "7.0 ",
        },
        {
            question: "Question 16:What is the data type of True or False in Python? ",
            options: ["Integer ", "String ", "Boolean ", "Float "],
            correctAnswer: "Boolean ",
        },
        {
            question: "Question 17: Which data type is ordered and mutable in Python?",
            options: ["String ", "Set ", "List ", "Tuple "],
            correctAnswer: "List ",
        },
        {
            question: "Question 18:What is the result of int(3.14) in Python? ",
            options: ["3 ", "3.0 ", "'3' ", "Error "],
            correctAnswer: "3 ",
        },
        {
            question: "Question 19:Which data type is used to represent a collection of unique elements? ",
            options: ["List ", "Set ", "Tuple ", "Dictionary "],
            correctAnswer: "Set ",
        },
        {
            question: "Question 20:What is the data type of the variable my_list if my_list = [1, 2, 3]? ",
            options: ["List ", "Set ", "Tuple ", "Dictionary "],
            correctAnswer: "List ",
        },
        {
            question: "Question 21: What is the value of 'Hello' + 'World' in Python?",
            options: ["'Hello World' ", "'Hello+World' ", "'HelloWorld' ", "Error "],
            correctAnswer: "'Hello World' ",
        },
        {
            question: "Question 22: What is the maximum value that can be stored in an int variable in Python?",
            options: [" There is no maximum value ", "2^64 - 1 ", "2^63 - 1 ", "2^31 - 1 "],
            correctAnswer: "2^63 - 1 ",
        },
        {
            question: "Question 23: What is the result of 3 * 'abc' in Python?",
            options: ["'abcabcabc' ", "9 ", "Error ", "'3abc' "],
            correctAnswer: "'abcabcabc' ",
        },
        {
            question: "Question 24: What is the purpose of the ord() function in Python?",
            options: ["To convert a string to uppercase ", "To calculate the absolute value of a number ", "To find the ASCII value of a character ", "To round a floating-point number "],
            correctAnswer: "To find the ASCII value of a character ",
        },
        {
            question: "Question 25:What is the result of 5 // 2 in Python? ",
            options: ["error ", "2 ", "2.0 ", "2.5 "],
            correctAnswer: "2 ",
        },
        {
            question: "Question 26: What is the data type of the variable my_dict if my_dict = {'name': 'John', 'age': 30}?",
            options: ["List ", "Set ", "Tuple ", "Dictionary "],
            correctAnswer: " ",
        },
        {
            question: "Question 27: What is the result of 2 ** 3 in Python?",
            options: ["8 ", "6 ", "16 ", "36 "],
            correctAnswer: "8 ",
        },
        {
            question: "Question 28:What is the result of round(3.5) in Python? ",
            options: ["3.0 ", "4 ", "4.0 ", "3 "],
            correctAnswer: "4 ",
        },
        {
            question: "Question 29: What is the data type of the variable my_set if my_set = {1, 2, 3}? ",
            options: ["List ", "Set ", "Tuple ", "Dictionary "],
            correctAnswer: "Set ",
        },
        {
            question: "Question 30:What is the result of len('Python') in Python? ",
            options: ["6 ", "5 ", "7 ", "No value "],
            correctAnswer: "5 ",
        }
    ];

    let currentQuestionIndex = 0;
    let score = 0;

    const questionTextElement = $("#question-text");
    const optionsContainer = $("#options-container");
    const feedbackTextElement = $("#feedback-text");
    const scoreElement = $("#score");
    const nextButton = $("#next-button");
    const retakeButton = $("#retake-button");

    function displayQuestion() {
        const question = questions[currentQuestionIndex];
        questionTextElement.text(question.question);
        optionsContainer.empty();

        for (const option of question.options) {
            const optionButton = $("<button>").text(option);
            optionButton.click(function() {
                checkAnswer(option, question.correctAnswer);
            });
            optionsContainer.append(optionButton);
        }
    }

    function checkAnswer(selectedOption, correctAnswer) {
        if (selectedOption === correctAnswer) {
            feedbackTextElement.text("Correct!");
            feedbackTextElement.removeClass("red-text");
            feedbackTextElement.addClass("green-text");
            score++;
        } else {
            feedbackTextElement.text("Wrong! The correct answer is: " + correctAnswer);
            feedbackTextElement.removeClass("green-text");
            feedbackTextElement.addClass("red-text");
        }

        scoreElement.text(score);
        nextButton.show();
        optionsContainer.children("button").prop("disabled", true);
    }

    function nextQuestion() {
        currentQuestionIndex++;

        if (currentQuestionIndex < questions.length) {
            displayQuestion();
            feedbackTextElement.text("");
            nextButton.hide();
            optionsContainer.children("button").prop("disabled", false);
        } else {
            endQuiz();
        }
    }

    function endQuiz() {
        questionTextElement.text("Quiz Completed!");
        optionsContainer.empty();
        feedbackTextElement.text("Your Score: " + score + " out of " + questions.length);
        retakeButton.show();
    }

    displayQuestion();

    nextButton.click(nextQuestion);

    retakeButton.click(function() {
        currentQuestionIndex = 0;
        score = 0;
        displayQuestion();
        scoreElement.text(score);
        feedbackTextElement.text("");
        nextButton.hide();
        optionsContainer.children("button").prop("disabled", false);
        retakeButton.hide();
    });
});